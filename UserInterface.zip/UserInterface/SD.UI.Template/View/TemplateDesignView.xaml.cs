﻿using System.Windows.Controls;

namespace SD.UI.Template.View
{
    /// <summary>
    /// Interaction logic for ServiceabilityDesignView.xaml
    /// </summary>
    public partial class TemplateDesignView : UserControl
    {
        public TemplateDesignView()
        {
            InitializeComponent();
        }
    }
}
