﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace SD.UI.Template.ViewModels
{
    public class TemplateDesignViewModel : ObservableObject
    {

    }
}
