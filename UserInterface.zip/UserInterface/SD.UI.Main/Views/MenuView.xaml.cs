﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for MenuView.xaml
    /// </summary>
    public partial class MenuView : System.Windows.Controls.UserControl
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}
