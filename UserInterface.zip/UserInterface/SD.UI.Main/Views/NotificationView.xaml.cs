﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for NotificationView.xaml
    /// </summary>
    public partial class NotificationView : System.Windows.Controls.UserControl
    {
        public NotificationView()
        {
            InitializeComponent();
        }
    }
}
