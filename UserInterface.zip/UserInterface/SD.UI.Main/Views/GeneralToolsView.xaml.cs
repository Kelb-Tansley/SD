﻿using System.Windows.Controls;

namespace SD.UI.Main.Views;

/// <summary>
/// Interaction logic for GeneralToolsView.xaml
/// </summary>
public partial class GeneralToolsView : UserControl
{
    public GeneralToolsView()
    {
        InitializeComponent();
    }
}
