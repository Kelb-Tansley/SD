﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for HeaderView.xaml
    /// </summary>
    public partial class HeaderView : System.Windows.Controls.UserControl
    {
        public HeaderView()
        {
            InitializeComponent();
        }
    }
}
