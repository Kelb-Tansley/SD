﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for ToolBarView.xaml
    /// </summary>
    public partial class ToolBarView : System.Windows.Controls.UserControl
    {
        public ToolBarView()
        {
            InitializeComponent();
        }
    }
}
