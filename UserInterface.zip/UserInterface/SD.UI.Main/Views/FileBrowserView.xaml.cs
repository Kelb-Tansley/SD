﻿namespace SD.UI.Main.Views;
public partial class FileBrowserView : System.Windows.Controls.UserControl
{
    public FileBrowserView()
    {
        InitializeComponent();
    }
}
