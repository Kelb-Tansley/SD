﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for NavigationView.xaml
    /// </summary>
    public partial class NavigationView : System.Windows.Controls.UserControl
    {
        public NavigationView()
        {
            InitializeComponent();
        }
    }
}
