﻿namespace SD.UI.Main.Views
{
    /// <summary>
    /// Interaction logic for DesignSettings.xaml
    /// </summary>
    public partial class DesignSettingsView : System.Windows.Controls.UserControl
    {
        public DesignSettingsView()
        {
            InitializeComponent();
        }
    }
}
