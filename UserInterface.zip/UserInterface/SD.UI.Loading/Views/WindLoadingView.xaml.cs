﻿using System.Windows.Controls;

namespace SD.UI.Loading.Views;

/// <summary>
/// Interaction logic for WindLoadingView.xaml
/// </summary>
public partial class WindLoadingView : UserControl
{
    public WindLoadingView()
    {
        InitializeComponent();
    }
}
