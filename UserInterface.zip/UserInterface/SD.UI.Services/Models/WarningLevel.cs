﻿namespace SD.UI.Services.Models;
public enum WarningLevel
{
    Info,
    Warning,
    Error
}
