﻿using System.Windows.Controls;

namespace SD.UI.Tools.Views;

/// <summary>
/// Interaction logic for BucklingAnalysisView.xaml
/// </summary>
public partial class BucklingAnalysisView : UserControl
{
    public BucklingAnalysisView()
    {
        InitializeComponent();
    }
}
