﻿using Prism.Events;
using SD.UI.Serviceability.Models;

namespace SD.UI.Serviceability.Events;
public class SelectedLoadCombinationsChangedEvent : PubSubEvent<CalculateEventModel> { }
