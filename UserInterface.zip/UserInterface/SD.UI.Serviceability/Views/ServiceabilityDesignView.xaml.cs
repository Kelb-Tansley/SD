﻿namespace SD.UI.Serviceability.Views
{
    /// <summary>
    /// Interaction logic for ServiceabilityDesignView.xaml
    /// </summary>
    public partial class ServiceabilityDesignView : System.Windows.Controls.UserControl
    {
        public ServiceabilityDesignView()
        {
            InitializeComponent();
        }
    }
}
