﻿namespace SD.UI.Serviceability.Views
{
    /// <summary>
    /// Interaction logic for LoadCombinationsView.xaml
    /// </summary>
    public partial class LoadCombinationsView : System.Windows.Controls.UserControl
    {
        public LoadCombinationsView()
        {
            InitializeComponent();
        }
    }
}
