﻿using Prism.Events;

namespace SD.UI.Events;
public class FileClosedEvent : PubSubEvent { }