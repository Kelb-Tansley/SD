﻿using Prism.Events;
using SD.Core.Shared.Models;
using SD.UI.Enums;

namespace SD.UI.Events;
public class GeneralToolsViewChangedEvent : PubSubEvent<GeneralToolsView> { }