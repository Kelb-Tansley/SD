﻿namespace SD.UI.Enums;
public enum GeneralToolsView
{
    WindLoading,
    BucklingAnalysis
}