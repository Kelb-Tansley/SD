﻿namespace SD.UI.Enums;
public enum LastEventEnum
{
    LengthChanged,
    LoadCaseChanged
}
