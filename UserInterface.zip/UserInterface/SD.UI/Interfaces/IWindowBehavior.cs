﻿using System.Windows;

namespace SD.UI.Interfaces;
public interface IWindowBehavior
{
    public Window MWindow { get; set; }
}
