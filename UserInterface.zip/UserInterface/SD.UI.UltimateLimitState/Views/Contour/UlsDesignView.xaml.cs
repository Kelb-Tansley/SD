﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for ServiceabilityDesignView.xaml
    /// </summary>
    public partial class UlsDesignView : System.Windows.Controls.UserControl
    {
        public UlsDesignView()
        {
            InitializeComponent();
        }
    }
}
