﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for LoadCombinationsView.xaml
    /// </summary>
    public partial class UlsLoadCombinationsView : System.Windows.Controls.UserControl
    {
        public UlsLoadCombinationsView()
        {
            InitializeComponent();
        }
    }
}
