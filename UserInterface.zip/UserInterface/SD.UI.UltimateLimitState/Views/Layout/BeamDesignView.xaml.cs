﻿namespace SD.UI.UltimateLimitState.Views
{
    public partial class BeamDesignView : System.Windows.Controls.UserControl
    {
        public BeamDesignView()
        {
            InitializeComponent();
        }
    }
}
