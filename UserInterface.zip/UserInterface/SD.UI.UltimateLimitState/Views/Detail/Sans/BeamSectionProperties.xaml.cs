﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for BeamSectionProperties.xaml
    /// </summary>
    public partial class BeamSectionProperties : System.Windows.Controls.UserControl
    {
        public BeamSectionProperties()
        {
            InitializeComponent();
        }
    }
}
