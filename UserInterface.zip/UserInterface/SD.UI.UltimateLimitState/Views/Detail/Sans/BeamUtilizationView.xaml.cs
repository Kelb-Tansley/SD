﻿namespace SD.UI.UltimateLimitState.Views;

/// <summary>
/// Interaction logic for BeamUtilizationView.xaml
/// </summary>
public partial class BeamUtilizationView : System.Windows.Controls.UserControl
{
    public BeamUtilizationView()
    {
        InitializeComponent();
    }
}
