﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for ASBeamCapacityView.xaml
    /// </summary>
    public partial class ASBeamCapacityView : System.Windows.Controls.UserControl
    {
        public ASBeamCapacityView()
        {
            InitializeComponent();
        }
    }
}
