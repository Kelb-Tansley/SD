﻿namespace SD.UI.UltimateLimitState.Views;

public partial class SelectedBeamDetailsView : System.Windows.Controls.UserControl
{
    public SelectedBeamDetailsView()
    {
        InitializeComponent();
    }
}
