﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for BeamEffectiveLengthView.xaml
    /// </summary>
    public partial class BeamEffectiveLengthView : System.Windows.Controls.UserControl
    {
        public BeamEffectiveLengthView()
        {
            InitializeComponent();
        }
    }
}
