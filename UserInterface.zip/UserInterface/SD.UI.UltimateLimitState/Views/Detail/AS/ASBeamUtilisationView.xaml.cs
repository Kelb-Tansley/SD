﻿namespace SD.UI.UltimateLimitState.Views;

/// <summary>
/// Interaction logic for ASBeamUtilisationView.xaml
/// </summary>
public partial class ASBeamUtilisationView : System.Windows.Controls.UserControl
{
    public ASBeamUtilisationView()
    {
        InitializeComponent();
    }
}
