﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for BeamCapacityView.xaml
    /// </summary>
    public partial class BeamCapacityView : System.Windows.Controls.UserControl
    {
        public BeamCapacityView()
        {
            InitializeComponent();
        }
    }
}
