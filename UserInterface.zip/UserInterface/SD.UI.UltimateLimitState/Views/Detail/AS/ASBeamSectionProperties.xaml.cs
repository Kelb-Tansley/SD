﻿namespace SD.UI.UltimateLimitState.Views
{
    /// <summary>
    /// Interaction logic for ASBeamSectionProperties.xaml
    /// </summary>
    public partial class ASBeamSectionProperties : System.Windows.Controls.UserControl
    {
        public ASBeamSectionProperties()
        {
            InitializeComponent();
        }
    }
}
