﻿namespace SD.Element.Design.Models;
public class ShearResistance(double vrMajor, double vrMinor)
{
    public double VrMajor { get; set; } = vrMajor;
    public double VrMinor { get; set; } = vrMinor;
}
