﻿namespace SD.Element.Design.AS.Enums;
public enum BeamAxisPart
{
    MajorTop,
    MajorBottom,
    MinorTop,
    MinorBottom
}