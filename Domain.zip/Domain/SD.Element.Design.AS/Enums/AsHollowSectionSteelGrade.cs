﻿namespace SD.Element.Design.AS.Enums;
public enum ASHollowSectionSteelGrade
{
    C250,
    C350,
    C450
}
