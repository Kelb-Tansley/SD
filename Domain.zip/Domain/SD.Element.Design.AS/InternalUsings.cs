﻿global using SD.Core.Shared.Contracts;
global using SD.Core.Shared.Enum;
global using SD.Core.Shared.Extensions;
global using SD.Core.Shared.Models;
global using SD.Core.Shared.Models.BeamModels;
global using SD.Core.Strand;
global using SD.Core.Strand.Models;
global using SD.Element.Design.Interfaces;
