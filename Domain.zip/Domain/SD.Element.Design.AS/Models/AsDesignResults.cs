﻿//using SD.Core.Shared.Models.AS;

//namespace SD.Element.Design.AS.Models
//{
//    public partial class ASDesignResults : IASDesignResults
//    {
//        public List<ASUlsResult>? AsUlsResults { get; set; }
//    }
//}