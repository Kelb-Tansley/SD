﻿namespace SD.Element.Design.Sans.Models;

public class CompressionAndBendingStrength
{
    public double CrossSectional { get; set; }
    public double OverallMember { get; set; }
    public double LateralTorsionalBuckling { get; set; }
}