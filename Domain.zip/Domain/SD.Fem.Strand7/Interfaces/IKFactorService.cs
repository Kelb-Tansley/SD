﻿namespace SD.Fem.Strand7.Interfaces;
public interface IKFactorService
{

}
