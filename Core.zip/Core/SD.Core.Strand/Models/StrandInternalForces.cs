﻿namespace SD.Core.Strand.Models;
public class StrandInternalForces
{

}
