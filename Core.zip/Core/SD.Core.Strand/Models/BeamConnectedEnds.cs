﻿namespace SD.Core.Strand.Models;
public class BeamConnectedEnds
{
    public int BeamEnd { get; set; }
    public int ComparisonBeamEnd { get; set; }
    public int NodeNumber { get; set; }
}
