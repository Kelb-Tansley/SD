﻿namespace SD.Core.Strand.Models;
public class Strand7ApiResponse
{
    public bool IsValid { get; set; } = false;
    public string? ErrorMessage { get; set; }
    public int ErrorCode { get; set; }
}
