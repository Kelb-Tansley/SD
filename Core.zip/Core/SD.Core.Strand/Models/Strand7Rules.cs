﻿namespace SD.Core.Strand.Models;
public class Strand7Rules
{
    public int MinStations { get; set; }
}