﻿namespace SD.Core.Strand.Helpers;
public class DllImportHelper
{
    public const string DllImportLocation = "St7api.dll";
}