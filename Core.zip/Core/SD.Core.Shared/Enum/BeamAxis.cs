﻿namespace SD.Core.Shared.Enum;
public enum BeamAxis
{
    Principal1,
    Principal2,
    PrincipalZ,
    PrincipalETop,
    PrincipalEBottom,
    All
}
