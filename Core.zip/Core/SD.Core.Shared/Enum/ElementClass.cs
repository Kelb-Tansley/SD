﻿namespace SD.Core.Shared.Enum;
public enum ElementClass
{
    Class1 = 1,
    Class2,
    Class3,
    Class4
}
