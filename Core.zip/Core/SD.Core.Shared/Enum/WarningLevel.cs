﻿namespace SD.Core.Shared.Enum;
public enum WarningLevel
{
    Info,
    Warning,
    Error
}
