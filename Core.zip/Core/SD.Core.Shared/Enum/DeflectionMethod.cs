﻿namespace SD.Core.Shared.Enum;
public enum DeflectionMethod
{
    Relative,
    Absolute
}
