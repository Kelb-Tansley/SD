﻿namespace SD.Core.Shared.Enum;
public enum DesignType
{
    NoDesign,
    Tension,
    Compression,
    Bending,
    BendingAxial
}
