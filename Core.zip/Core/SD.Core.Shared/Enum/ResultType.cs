﻿namespace SD.Core.Shared.Enum;
public enum ResultType
{
    Force,
    Deflection,
    BeamLength,
    Slenderness
}