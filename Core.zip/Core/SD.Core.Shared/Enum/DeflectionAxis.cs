﻿namespace SD.Core.Shared.Enum;
public enum DeflectionAxis
{
    X,
    Y,
    Z
}
