﻿namespace SD.Core.Shared.Enum;
public enum DesignCode
{
    SANS,
    AS
}
