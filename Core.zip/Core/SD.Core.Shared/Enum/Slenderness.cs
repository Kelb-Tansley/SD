﻿namespace SD.Core.Shared.Enum;
public enum Slenderness
{
    Compact,
    NonCompact,
    Slender
}