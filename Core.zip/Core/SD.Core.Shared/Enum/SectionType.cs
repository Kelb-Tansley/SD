﻿namespace SD.Core.Shared.Enum;
public enum SectionType
{
    IorH,
    LipChannel,
    Angle,
    CircularHollow,
    RectangularHollow,
    T,
    Unknown
}
