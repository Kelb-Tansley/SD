﻿namespace SD.Core.Shared.Enum;
public enum GlobalAxis
{
    X = 1,
    Y,
    Z,
    NotAlligned
}
