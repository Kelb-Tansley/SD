﻿namespace SD.Core.Shared.Enum;
public enum ZoomLevel
{
    Level0,
    Level1,
    Level2,
    Level3,
    Level4,
    Level5
}
