﻿namespace SD.Core.Shared.Constants;
public static class DesignServiceTypes
{
    public const string SansDesign = "SANS 10162-1:2011";
    public const string ASDesign = "AS 4100-2020";
}