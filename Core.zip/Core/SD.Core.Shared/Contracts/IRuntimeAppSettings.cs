﻿namespace SD.Core.Shared.Contracts;
public interface IRuntimeAppSettings
{
    public bool RequiresRestart { get; set; }
}

