﻿namespace SD.Core.Shared.Contracts;
public interface IDesignService
{
    public void CloseDesignWindow();
    public void ShowDesignWindow();
}
