﻿using Prism.Events;

namespace SD.Core.Shared.Events;
public class AppRestartEvent : PubSubEvent { }
