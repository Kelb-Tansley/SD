﻿namespace SD.Core.Shared.Models;
public class UnitFactor
{
    public double Length { get; set; }
    public double Force { get; set; }
    public double Stress { get; set; }
}
