﻿namespace SD.Core.Shared.Models;
public class Strand7Api
{
    public List<LocationDetail> Paths { get; set; }
    public int Delay { get; set; }
    public int RetryCount { get; set; }
}
