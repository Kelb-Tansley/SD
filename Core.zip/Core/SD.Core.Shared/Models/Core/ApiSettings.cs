﻿namespace SD.Core.Shared.Models.Core;
public class ApiSettings
{
    public string AppRegClientId { get; set; }
    public string AppRegTenantId { get; set; }
}
