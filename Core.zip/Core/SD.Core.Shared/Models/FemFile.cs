﻿namespace SD.Core.Shared.Models;
public class FemFile
{
    public string FemModelFilePath { get; set; } = string.Empty;
}
