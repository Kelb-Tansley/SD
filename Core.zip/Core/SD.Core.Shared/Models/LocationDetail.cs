﻿namespace SD.Core.Shared.Models;

public class LocationDetail
{
    public string? Location { get; set; }
    public string? Value { get; set; }
}