﻿using System.Windows;

namespace Hatch.Pdg.SD.Views;
public partial class Shell : Window
{
    public Shell()
    {
        InitializeComponent();
    }
}
