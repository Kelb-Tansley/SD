﻿using System.Windows;

namespace Hatch.Pdg.SD.Views;
public partial class Design : Window
{
    public Design()
    {
        InitializeComponent();
    }
}