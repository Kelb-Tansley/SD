﻿namespace Hatch.Pdg.SD.Constants;
public class OurUsers
{
    public static string[] AuthorisedUsers()
    {
        return
        [
            "kelby.tansley@hatch.com",
            "chris.dewet@hatch.com",
            "caleb.napier@hatch.com",
            "alex.colley@hatch.com",
            "mishkal.bramdaw@hatch.com",
            "michael.harrison@hatch.com",
            "gillian.cox@hatch.com",
            "gary.hooper@hatch.com",
            "rachel.groenewald@hatch.com",
            "werner.pieters@hatch.com"
        ];
    }
}
